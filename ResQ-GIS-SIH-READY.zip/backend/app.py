"""
ResQ-GIS Flask API Gateway
Provides all required endpoints corresponding to Node/Express service.
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from services.data_orchestrator import orchestrator, is_point_in_india
from services.risk_engine import risk_engine, calculate_haversine
from services.ml_engine import spatial_cnn, hydro_lstm, vision_resnet
import json

app = Flask(__name__)
CORS(app)

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'healthy',
        'service': 'ResQ-GIS Flask Python Backend',
        'country': 'Republic of India',
        'boundary_enforcement': 'Active Point-in-Polygon (PIP)',
        'ml_models': ['ResQ-Spatial-CNN', 'ResQ-Hydro-LSTM', 'ResQ-Vision-ResNet50']
    })

@app.route('/api/weather', methods=['GET'])
def get_weather():
    lat = float(request.args.get('lat', 11.5173))
    lon = float(request.args.get('lon', 76.1368))
    if not is_point_in_india(lat, lon):
        return jsonify({'error': 'Coordinates lie outside India'}), 400
    try:
        data = orchestrator.fetch_weather(lat, lon)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/earthquakes', methods=['GET'])
def get_earthquakes():
    quakes = orchestrator.fetch_earthquakes()
    return jsonify({'count': len(quakes), 'earthquakes': quakes})

@app.route('/api/risk/<float:lat>/<float:lon>', methods=['GET'])
def get_risk(lat, lon):
    if not is_point_in_india(lat, lon):
        return jsonify({'error': 'Coordinates lie outside sovereign borders of India'}), 400
    hazard = request.args.get('hazard', 'landslide')
    weather = orchestrator.fetch_weather(lat, lon)
    slope = 34.0 if lat < 14.0 else (38.0 if lat > 29.0 else 3.0)

    if hazard == 'landslide':
        hist_score, cur_score, expl = risk_engine.calculate_landslide_risk(weather, slope, 4)
    else:
        hist_score, cur_score, expl = risk_engine.calculate_flood_risk(weather, slope, 4)

    cnn_score = spatial_cnn.forward_simulate(weather['elevation_m'], slope, weather['rainfall_3d_mm'])
    lstm_score = hydro_lstm.forward_simulate(weather['rainfall_7d_mm'], weather['soil_moisture_percent'])

    level = 'RED' if cur_score >= 75 else ('ORANGE' if cur_score >= 55 else ('YELLOW' if cur_score >= 35 else 'GREEN'))

    return jsonify({
        'coordinates': [lat, lon],
        'hazard': hazard,
        'current_risk_level': level,
        'current_risk_score': cur_score,
        'historical_susceptibility_score': hist_score,
        'cnn_spatial_score': cnn_score,
        'lstm_sequence_score': lstm_score,
        'explanation': expl,
        'weather_snapshot': weather
    })

if __name__ == '__main__':
    print("[ResQ-GIS] Starting Flask Backend on port 5000...")
    app.run(host='0.0.0.0', port=5000, debug=True)
