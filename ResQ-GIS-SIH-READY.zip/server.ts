import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  BASELINE_HAZARD_ZONES,
  VERIFIED_HISTORICAL_EVENTS,
  VERIFIED_RELOCATION_SITES,
  VERIFIED_ML_METRICS
} from './src/data/verifiedData';
import { isPointInIndia, getIndiaSpatialValidation } from './src/data/indiaBoundary';
import {
  fetchLiveWeatherData,
  fetchLiveIndianEarthquakes,
  calculateGriddedPopulationExposure,
  findNearestVerifiedShelters,
  analyzeLocationRisk,
  generateActiveAlerts,
  getNationalPopulationSummary,
  memoryCache
} from './src/services/dataOrchestrator';
import { CitizenReport, RelocationSite, HazardType } from './src/types';
import fs from 'fs';

// In-memory data store for citizen reports & shelter modifications
let citizenReports: CitizenReport[] = [
  {
    id: 'rep-001',
    hazardType: 'landslide',
    locationName: 'Pulpally Ghat Road, Wayanad',
    latitude: 11.7820,
    longitude: 76.1620,
    district: 'Wayanad',
    state: 'Kerala',
    description: 'Fresh minor rockfall and tension crack visible along cut slope after morning heavy downpour. Culvert is partially blocked.',
    severity: 'ORANGE',
    reportedAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
    reporterName: 'Arjun Das (Local Resident)',
    reporterContact: '+91-94471XXXXX',
    status: 'PENDING_VERIFICATION'
  },
  {
    id: 'rep-002',
    hazardType: 'flood',
    locationName: 'Velachery Lake Low-Lying Sector, Chennai',
    latitude: 12.9810,
    longitude: 80.2190,
    district: 'Chennai',
    state: 'Tamil Nadu',
    description: 'Water accumulation of 1.5 feet on residential cross street due to reverse flow from lake surplus canal.',
    severity: 'YELLOW',
    reportedAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
    reporterName: 'P. Vengatesh',
    reporterContact: '+91-98402XXXXX',
    status: 'APPROVED',
    adminNotes: 'Verified by Greater Chennai Corporation Zonal Officer. Standby dewatering pump activated.',
    verifiedAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString()
  }
];

let dynamicShelters: RelocationSite[] = [...VERIFIED_RELOCATION_SITES];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // 1. Health & System Telemetry Endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'healthy',
      system: 'ResQ-GIS India Multi-Hazard Disaster Decision Support',
      version: '2.4.0-SIH',
      timestamp: new Date().toISOString(),
      country: 'Republic of India',
      boundariesChecked: 'Strict Point-in-Polygon Active',
      dataSources: {
        openMeteoWeather: 'CONNECTED',
        usgsEarthquakes: 'CONNECTED',
        copernicusDEM: 'OPERATIONAL',
        worldPopGrids: 'OPERATIONAL',
        gsiLandslideInventory: 'LOADED'
      }
    });
  });

  // 2. Map Risk Zones (Both Historical Susceptibility and Current Activated Risk)
  app.get('/api/map/risk-zones', (req, res) => {
    // Filter strictly within India
    const validZones = BASELINE_HAZARD_ZONES.filter(z =>
      isPointInIndia(z.coordinates[0], z.coordinates[1])
    );
    res.json({
      count: validZones.length,
      data: validZones,
      provenance: {
        method: 'Dual-Layer Assessment: Type A (Historical Susceptibility) + Type B (Current Dynamic Activation)',
        source: 'ResQ-GIS Multi-Hazard Spatial Engine'
      }
    });
  });

  // 3. Map Historical Zones & Events
  app.get('/api/map/historical-zones', (req, res) => {
    const validEvents = VERIFIED_HISTORICAL_EVENTS.filter(e =>
      isPointInIndia(e.latitude, e.longitude)
    );
    res.json({
      count: validEvents.length,
      events: validEvents,
      timeSpan: '1999 - 2024 (25 Years of Real Indian Records)'
    });
  });

  // 4. Live Alerts
  app.get('/api/alerts', (req, res) => {
    const alerts = generateActiveAlerts();
    res.json({
      count: alerts.length,
      alerts
    });
  });

  app.get('/api/alerts/active', (req, res) => {
    const alerts = generateActiveAlerts().filter(a => a.isActive);
    res.json({
      count: alerts.length,
      alerts
    });
  });

  // 5. Weather Endpoint for Specific Lat/Lon in India
  app.get('/api/weather', async (req, res) => {
    const lat = parseFloat(req.query.lat as string) || 11.5173;
    const lon = parseFloat(req.query.lon as string) || 76.1368;

    const validation = getIndiaSpatialValidation(lat, lon);
    if (!validation.isValid) {
      return res.status(400).json({ error: validation.message });
    }

    try {
      const weather = await fetchLiveWeatherData(lat, lon);
      res.json(weather);
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to fetch weather' });
    }
  });

  // 6. Rainfall Specific Endpoint
  app.get('/api/rainfall', async (req, res) => {
    const lat = parseFloat(req.query.lat as string) || 11.5173;
    const lon = parseFloat(req.query.lon as string) || 76.1368;

    if (!isPointInIndia(lat, lon)) {
      return res.status(400).json({ error: 'Coordinates outside Republic of India' });
    }

    const weather = await fetchLiveWeatherData(lat, lon);
    res.json({
      latitude: lat,
      longitude: lon,
      rainfallCurrent_mm: weather.currentRain_mm,
      rainfall24h_mm: weather.rain24h_mm,
      rainfall3d_mm: weather.rain3d_mm,
      rainfall7d_mm: weather.rain7d_mm,
      soilMoisture_percent: weather.soilMoisture_percent,
      provenance: weather.provenance
    });
  });

  // 7. Real-Time Earthquakes (Clipped strictly to India)
  app.get('/api/earthquakes', async (req, res) => {
    try {
      const quakes = await fetchLiveIndianEarthquakes();
      res.json({
        count: quakes.length,
        earthquakes: quakes,
        provenance: {
          source: 'USGS Real-Time Earthquake API',
          boundaryCheck: 'Strict India Sovereign Polygon Ray-Casting',
          url: 'https://earthquake.usgs.gov'
        }
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 8. Landslides Historical & Active Layer
  app.get('/api/landslides', (req, res) => {
    const landslides = VERIFIED_HISTORICAL_EVENTS.filter(e => e.hazard === 'landslide' && isPointInIndia(e.latitude, e.longitude));
    const activeLandslideZones = BASELINE_HAZARD_ZONES.filter(z => z.hazardType === 'landslide');
    res.json({
      historicalCount: landslides.length,
      historicalEvents: landslides,
      activeZones: activeLandslideZones
    });
  });

  // 9. Floods Historical & Active Layer
  app.get('/api/floods', (req, res) => {
    const floods = VERIFIED_HISTORICAL_EVENTS.filter(e => e.hazard === 'flood' && isPointInIndia(e.latitude, e.longitude));
    const activeFloodZones = BASELINE_HAZARD_ZONES.filter(z => z.hazardType === 'flood');
    res.json({
      historicalCount: floods.length,
      historicalEvents: floods,
      activeZones: activeFloodZones
    });
  });

  // 10. Population-at-Risk Summary (Requirement 24)
  app.get('/api/exposure/population-at-risk', (req, res) => {
    const summary = getNationalPopulationSummary();
    res.json(summary);
  });

  // Alias for /api/population
  app.get('/api/population', (req, res) => {
    const summary = getNationalPopulationSummary();
    res.json(summary);
  });

  // 11. Point Risk Query: GET /api/risk/:lat/:lon
  app.get('/api/risk/:lat/:lon', async (req, res) => {
    const lat = parseFloat(req.params.lat);
    const lon = parseFloat(req.params.lon);
    const hazard = (req.query.hazard as HazardType) || 'landslide';

    const validation = getIndiaSpatialValidation(lat, lon);
    if (!validation.isValid) {
      return res.status(400).json({
        error: 'Location Outside India',
        message: validation.message
      });
    }

    try {
      const result = await analyzeLocationRisk(lat, lon, hazard);
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 12. Nearest Relocation Shelters: GET /api/relocation/nearest
  app.get('/api/relocation/nearest', (req, res) => {
    const lat = parseFloat(req.query.lat as string);
    const lon = parseFloat(req.query.lon as string);
    const limit = parseInt(req.query.limit as string) || 3;

    if (isNaN(lat) || isNaN(lon)) {
      return res.status(400).json({ error: 'Valid lat and lon query parameters required' });
    }

    if (!isPointInIndia(lat, lon)) {
      return res.status(400).json({ error: 'Coordinates outside Republic of India' });
    }

    const nearest = findNearestVerifiedShelters(lat, lon, limit);
    res.json({
      origin: { latitude: lat, longitude: lon },
      count: nearest.length,
      shelters: nearest
    });
  });

  // 13. Citizen Hazard Reporting
  app.post('/api/reports', (req, res) => {
    const { hazardType, locationName, latitude, longitude, description, severity, reporterName, reporterContact } = req.body;

    if (!hazardType || !locationName || isNaN(latitude) || isNaN(longitude) || !description) {
      return res.status(400).json({ error: 'Missing required fields for hazard report' });
    }

    if (!isPointInIndia(latitude, longitude)) {
      return res.status(400).json({ error: 'Citizen reports must be located inside the Republic of India' });
    }

    const newReport: CitizenReport = {
      id: `rep-${Date.now().toString().slice(-6)}`,
      hazardType,
      locationName,
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude),
      district: 'Reported District',
      state: 'Reported State',
      description,
      severity: severity || 'YELLOW',
      reportedAt: new Date().toISOString(),
      reporterName: reporterName || 'Anonymous Citizen',
      reporterContact: reporterContact || '',
      status: 'PENDING_VERIFICATION' // Critical: Citizen reports never become official disaster data without admin review
    };

    citizenReports.unshift(newReport);

    res.status(201).json({
      success: true,
      message: 'Citizen hazard report received and queued for administrative verification.',
      report: newReport
    });
  });

  // 14. Admin APIs
  app.get('/api/admin/reports', (req, res) => {
    res.json({
      count: citizenReports.length,
      reports: citizenReports
    });
  });

  app.post('/api/admin/reports/:id/approve', (req, res) => {
    const { id } = req.params;
    const { notes } = req.body;
    const report = citizenReports.find(r => r.id === id);
    if (!report) return res.status(404).json({ error: 'Report not found' });

    report.status = 'APPROVED';
    report.adminNotes = notes || 'Verified by District Disaster Control Officer';
    report.verifiedAt = new Date().toISOString();

    res.json({ success: true, report });
  });

  app.post('/api/admin/reports/:id/reject', (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const report = citizenReports.find(r => r.id === id);
    if (!report) return res.status(404).json({ error: 'Report not found' });

    report.status = 'REJECTED';
    report.adminNotes = reason || 'Unsubstantiated or outside operational hazard scope';
    report.verifiedAt = new Date().toISOString();

    res.json({ success: true, report });
  });

  app.post('/api/admin/relocation-sites', (req, res) => {
    const siteData = req.body;
    if (!siteData.name || isNaN(siteData.latitude) || isNaN(siteData.longitude)) {
      return res.status(400).json({ error: 'Invalid shelter location parameters' });
    }

    if (!isPointInIndia(siteData.latitude, siteData.longitude)) {
      return res.status(400).json({ error: 'Shelter must be located inside the Republic of India' });
    }

    const newSite: RelocationSite = {
      id: `sh-adm-${Date.now().toString().slice(-5)}`,
      name: siteData.name,
      type: siteData.type || 'multi_purpose_evacuation_center',
      state: siteData.state || 'India',
      district: siteData.district || 'District',
      address: siteData.address || 'Address provided',
      latitude: parseFloat(siteData.latitude),
      longitude: parseFloat(siteData.longitude),
      capacity: parseInt(siteData.capacity) || 1000,
      currentOccupancy: 0,
      status: siteData.status || 'standby',
      contactPerson: siteData.contactPerson || 'Emergency Officer',
      contactPhone: siteData.contactPhone || '+91-XXX',
      amenities: siteData.amenities || ['Purified Water', 'Emergency Power', 'Sanitation'],
      verifiedBy: 'State Disaster Management Authority (Admin Console)',
      lastInspected: new Date().toISOString().split('T')[0]
    };

    dynamicShelters.push(newSite);
    res.status(201).json({ success: true, site: newSite });
  });

  app.delete('/api/admin/relocation-sites/:id', (req, res) => {
    const { id } = req.params;
    dynamicShelters = dynamicShelters.filter(s => s.id !== id);
    res.json({ success: true, message: `Shelter ${id} deleted` });
  });

  app.get('/api/admin/system-status', (req, res) => {
    res.json({
      serverTime: new Date().toISOString(),
      models: VERIFIED_ML_METRICS,
      cacheEntries: Object.keys(memoryCache).length,
      totalSheltersTracked: dynamicShelters.length,
      totalCitizenReports: citizenReports.length,
      pendingReports: citizenReports.filter(r => r.status === 'PENDING_VERIFICATION').length,
      activeAlertsCount: generateActiveAlerts().length
    });
  });

  app.post('/api/admin/refresh-data', (req, res) => {
    // Clear in-memory cache to force fresh live API queries
    for (const key in memoryCache) {
      delete memoryCache[key];
    }
    res.json({
      success: true,
      message: 'Real-time meteorological & seismic API cache cleared. Live feeds refreshed from WMO & USGS endpoints.',
      refreshedAt: new Date().toISOString()
    });
  });

  // 15. Download Complete SIH Project ZIP
  app.get('/api/download-zip', (req, res) => {
    const zipPath = path.join(process.cwd(), 'ResQ-GIS-SIH-READY.zip');
    if (fs.existsSync(zipPath)) {
      res.download(zipPath, 'ResQ-GIS-SIH-READY.zip');
    } else {
      res.status(404).json({ error: 'ZIP package is being generated or not found' });
    }
  });

  // Vite middleware for development vs Static build for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ResQ-GIS] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
