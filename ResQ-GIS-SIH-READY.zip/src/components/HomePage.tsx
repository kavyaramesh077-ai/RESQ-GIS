import React from 'react';
import {
  ShieldAlert,
  MapPin,
  Cpu,
  Layers,
  Building2,
  CheckCircle2,
  ArrowRight,
  Database,
  Radio,
  ExternalLink,
  Users
} from 'lucide-react';
import { RiskZone, AlertItem } from '../types';

interface HomePageProps {
  riskZones: RiskZone[];
  activeAlerts: AlertItem[];
  onNavigate: (page: string) => void;
  onOpenDownload: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  riskZones,
  activeAlerts,
  onNavigate,
  onOpenDownload
}) => {
  const redAlerts = activeAlerts.filter(a => a.severity === 'RED');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 text-slate-100">
      {/* Hero / System Mission Section */}
      <section className="bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 sm:p-10 relative overflow-hidden shadow-xl">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-400 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Smart India Hackathon (SIH) Ready Production Architecture
          </div>

          <h1 className="text-2xl sm:text-4xl font-bold tracking-tight text-white leading-tight">
            ResQ-GIS — India Multi-Hazard GIS, AI Risk Analysis & Early Warning System
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            A real-world decision-support system designed to reduce loss of life from natural hazards across the Republic of India.
            Operating under a strict <strong className="text-emerald-400 font-semibold">Zero Fake Data</strong> protocol, ResQ-GIS continuously couples live atmospheric forecasts with 30m Copernicus terrain gradients, GSI/CWC historical hazard inventories, and WorldPop gridded demographic exposure models.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('dashboard')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              <span>Explore Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('map')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              <span>Open India GIS Map</span>
            </button>

            <button
              onClick={() => onNavigate('ai-analyzer')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-900/60 hover:bg-blue-800/80 border border-blue-700 text-blue-200 text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              <Cpu className="w-3.5 h-3.5 text-blue-400" />
              <span>Launch AI Risk Analyzer</span>
            </button>
          </div>
        </div>

        {/* Live System Telemetry Badge Card */}
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 border-t border-slate-800/80 pt-6 text-xs">
          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Sovereign Jurisdiction</span>
            <span className="font-bold text-slate-100 font-mono">Republic of India</span>
            <span className="text-[10px] text-emerald-400 block mt-0.5">Strict Point-in-Polygon Check</span>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Atmospheric Feed</span>
            <span className="font-bold text-slate-100 font-mono">Open-Meteo NWP</span>
            <span className="text-[10px] text-emerald-400 block mt-0.5">24h / 3d / 7d Live Hourly</span>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Seismic Observation</span>
            <span className="font-bold text-slate-100 font-mono">USGS Catalog</span>
            <span className="text-[10px] text-emerald-400 block mt-0.5">Real-Time Indian Coordinates</span>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 text-[11px] block">Population Model</span>
            <span className="font-bold text-slate-100 font-mono">WorldPop 2025</span>
            <span className="text-[10px] text-emerald-400 block mt-0.5">1 km Gridded Spatial Density</span>
          </div>
        </div>
      </section>

      {/* Core Architectural Pillars */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">System Architectural Distinctions</h2>
          <p className="text-xs text-slate-400">Engineering principles separating ResQ-GIS from generic dashboard templates</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-xl space-y-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h3 className="text-sm font-bold text-slate-200">The Two Types of Risk</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Distinguishes between <strong className="text-slate-200">Type A (Historical Susceptibility)</strong> and <strong className="text-slate-200">Type B (Current Dynamic Activation)</strong>. A mountain tract in Wayanad or a low-lying basin in Chennai retains permanent historical susceptibility even during dry spells, with risk elevating dynamically when 24h/3d rainfall triggers are breached.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-xl space-y-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-950 text-blue-400 border border-blue-800 flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h3 className="text-sm font-bold text-slate-200">India Sovereign Boundary Clipping</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every coordinate, hazard polygon, alert, and gridded population count is verified with ray-casting point-in-polygon checks. Neighboring sovereign nations (Pakistan, China, Nepal, Bhutan, Bangladesh, Myanmar, Sri Lanka) receive zero alerts or risk tags.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-xl space-y-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h3 className="text-sm font-bold text-slate-200">Zero Fake Data Protocol</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Never invents synthetic disasters or hard-codes cities as red for visual effect. Every metric contains verifiable scientific provenance: data source name, live query URL, timestamp, observation date, and processing methodology.
            </p>
          </div>
        </div>
      </section>

      {/* Quick Navigation Cards */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">Dedicated Decision-Support Modules</h2>
          <p className="text-xs text-slate-400">Ten purpose-built operational interfaces for emergency managers, researchers, and citizens</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div 
            onClick={() => onNavigate('dashboard')}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 flex items-center gap-2">
                <Radio className="w-4 h-4 text-emerald-500" />
                Overview Dashboard
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-xs text-slate-400">National multi-hazard risk distribution, active alert summaries, and population exposure overview.</p>
          </div>

          <div 
            onClick={() => onNavigate('alerts')}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-500" />
                Live Alerts Engine
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-xs text-slate-400">Automated warning bulletins with complete physical evidence, forecast triggers, and recommended civil defense protocols.</p>
          </div>

          <div 
            onClick={() => onNavigate('ai-analyzer')}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-blue-400" />
                AI Risk Analyzer
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-xs text-slate-400">Deep scientific inference for any coordinate in India using coupled CNN/LSTM models and physical terrain derivatives.</p>
          </div>

          <div 
            onClick={() => onNavigate('historical')}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 flex items-center gap-2">
                <Database className="w-4 h-4 text-amber-400" />
                Historical Hazards
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-xs text-slate-400">25 years of documented Indian disaster events from GSI, CWC, and IMD with seasonality and recurrence analytics.</p>
          </div>

          <div 
            onClick={() => onNavigate('population')}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-400" />
                Population at Risk
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-xs text-slate-400">WorldPop gridded population density intersections calculating Red, Orange, and Yellow exposed communities.</p>
          </div>

          <div 
            onClick={() => onNavigate('relocation')}
            className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                Relocation & Shelters
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:translate-x-1 transition-transform" />
            </div>
            <p className="text-xs text-slate-400">Haversine distance routing to nearest 3 verified multi-purpose cyclone shelters and flood relief camps.</p>
          </div>
        </div>
      </section>
    </div>
  );
};
