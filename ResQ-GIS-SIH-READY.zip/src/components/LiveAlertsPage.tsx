import React, { useState } from 'react';
import { ShieldAlert, Filter, Clock, MapPin, AlertCircle, CheckCircle, ExternalLink } from 'lucide-react';
import { AlertItem, HazardType, RiskLevel } from '../types';

interface LiveAlertsPageProps {
  alerts: AlertItem[];
  onNavigateToMap: () => void;
}

export const LiveAlertsPage: React.FC<LiveAlertsPageProps> = ({
  alerts,
  onNavigateToMap
}) => {
  const [selectedHazard, setSelectedHazard] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');

  const filteredAlerts = alerts.filter(a => {
    if (selectedHazard !== 'all' && a.hazard !== selectedHazard) return false;
    if (selectedSeverity !== 'all' && a.severity !== selectedSeverity) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <ShieldAlert className="w-6 h-6 text-rose-500" />
              Automated Early Warning & Alert Bulletins
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Active multi-hazard alerts generated automatically when real-time environmental triggers cross physical safety thresholds
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">
              Showing <strong className="text-white font-mono">{filteredAlerts.length}</strong> of <strong className="text-white font-mono">{alerts.length}</strong> alerts
            </span>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3 pt-3">
          {/* Hazard Filter */}
          <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Hazard:</span>
            <select
              value={selectedHazard}
              onChange={e => setSelectedHazard(e.target.value)}
              className="bg-transparent text-slate-200 font-semibold focus:outline-none"
            >
              <option value="all" className="bg-slate-900">All Hazards</option>
              <option value="landslide" className="bg-slate-900">Landslide</option>
              <option value="flood" className="bg-slate-900">Flood</option>
              <option value="cyclone" className="bg-slate-900">Cyclone</option>
              <option value="earthquake" className="bg-slate-900">Earthquake</option>
            </select>
          </div>

          {/* Severity Filter */}
          <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
            <span className="text-slate-400">Severity:</span>
            <select
              value={selectedSeverity}
              onChange={e => setSelectedSeverity(e.target.value)}
              className="bg-transparent text-slate-200 font-semibold focus:outline-none"
            >
              <option value="all" className="bg-slate-900">All Severities</option>
              <option value="RED" className="bg-slate-900 text-rose-400">RED (Very High)</option>
              <option value="ORANGE" className="bg-slate-900 text-amber-400">ORANGE (High)</option>
              <option value="YELLOW" className="bg-slate-900 text-yellow-400">YELLOW (Moderate)</option>
              <option value="GREEN" className="bg-slate-900 text-emerald-400">GREEN (Low)</option>
            </select>
          </div>

          <button
            onClick={() => { setSelectedHazard('all'); setSelectedSeverity('all'); }}
            className="text-xs text-slate-400 hover:text-slate-200 underline cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      </div>

      {/* Alerts Cards List */}
      {filteredAlerts.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/40 border border-slate-800 rounded-xl space-y-2">
          <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-200">No Active Warnings Match Selection</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Environmental triggers are currently within calibrated baseline tolerances for this filter criteria.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredAlerts.map(alert => {
            const isRed = alert.severity === 'RED';
            const isOrange = alert.severity === 'ORANGE';
            const isYellow = alert.severity === 'YELLOW';

            const borderColor = isRed ? 'border-rose-700/80 bg-rose-950/20' : isOrange ? 'border-amber-700/80 bg-amber-950/20' : 'border-yellow-700/80 bg-yellow-950/20';
            const badgeBg = isRed ? 'bg-rose-600 text-white' : isOrange ? 'bg-amber-600 text-white' : 'bg-yellow-500 text-slate-950';

            return (
              <div
                key={alert.id}
                className={`p-5 rounded-xl border transition-all space-y-4 shadow-md ${borderColor} bg-slate-900`}
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${badgeBg}`}>
                        {alert.severity} — {isRed ? 'VERY HIGH RISK' : isOrange ? 'HIGH RISK' : 'MODERATE ADVISORY'}
                      </span>
                      <span className="text-[11px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {alert.hazard}
                      </span>
                      <span className="text-xs text-slate-400 font-mono hidden md:inline">
                        Risk Score: <strong className="text-white">{alert.riskScore}/100</strong>
                      </span>
                    </div>
                    <h2 className="text-base font-bold text-white flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400" />
                      {alert.location}
                      <span className="text-xs font-normal text-slate-400">
                        ({alert.district}, {alert.state})
                      </span>
                    </h2>
                  </div>

                  <div className="text-left sm:text-right space-y-0.5">
                    <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1 sm:justify-end">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{new Date(alert.timestamp).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST</span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">
                      Coords: {alert.latitude.toFixed(4)}°N, {alert.longitude.toFixed(4)}°E (India)
                    </div>
                  </div>
                </div>

                {/* Evidence Grid: Current, Historical, Forecast */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block">
                      1. Current Physical Conditions
                    </span>
                    <p className="text-slate-300 leading-relaxed">{alert.currentCondition}</p>
                  </div>

                  <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block">
                      2. Historical Hazard Recurrence
                    </span>
                    <p className="text-slate-300 leading-relaxed">{alert.historicalEvidence}</p>
                  </div>

                  <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 space-y-1">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block">
                      3. Forecast Progression
                    </span>
                    <p className="text-slate-300 leading-relaxed">{alert.forecastEvidence}</p>
                  </div>
                </div>

                {/* Physical Reason & Civil Defense Action */}
                <div className="space-y-2 text-xs">
                  <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/80">
                    <strong className="text-slate-200 block mb-1">Causal Reason:</strong>
                    <p className="text-slate-300 leading-relaxed">{alert.reason}</p>
                  </div>

                  <div className="bg-emerald-950/30 p-3 rounded-lg border border-emerald-900/50">
                    <strong className="text-emerald-400 block mb-1">Recommended Response Action:</strong>
                    <p className="text-emerald-200 leading-relaxed">{alert.recommendedAction}</p>
                  </div>
                </div>

                {/* Footer: Population Exposed & Provenance */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                  <div>
                    Population in Risk Zone: <strong className="text-slate-200 font-mono">{alert.populationAtRisk.toLocaleString()}</strong> (WorldPop 1km estimation)
                  </div>
                  <div className="flex items-center gap-1 font-mono">
                    <span>Source: {alert.dataSources[0]?.source || 'Open-Meteo & Copernicus DEM'}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
