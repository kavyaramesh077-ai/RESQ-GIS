import React, { useState } from 'react';
import { Megaphone, MapPin, Send, AlertTriangle, CheckCircle, ShieldAlert, Info } from 'lucide-react';
import { HazardType, RiskLevel, CitizenHazardReport } from '../types';
import { isPointInIndia, getIndiaSpatialValidation } from '../data/indiaBoundary';

interface ReportHazardPageProps {
  onSubmitSuccess: () => void;
}

export const ReportHazardPage: React.FC<ReportHazardPageProps> = ({ onSubmitSuccess }) => {
  const [locationName, setLocationName] = useState('');
  const [stateName, setStateName] = useState('Kerala');
  const [district, setDistrict] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [hazardType, setHazardType] = useState<HazardType>('landslide');
  const [severity, setSeverity] = useState<RiskLevel>('ORANGE');
  const [description, setDescription] = useState('');
  const [reporterName, setReporterName] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);

    if (isNaN(lat) || isNaN(lon)) {
      setErrorMessage('Please provide valid numerical geographic coordinates.');
      return;
    }

    const validation = getIndiaSpatialValidation(lat, lon);
    if (!validation.isValid) {
      setErrorMessage(validation.message);
      return;
    }

    if (!locationName.trim() || !description.trim()) {
      setErrorMessage('Please fill in location name and hazard description.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        locationName,
        state: stateName,
        district: district || 'Unspecified',
        coordinates: [lat, lon],
        hazardType,
        severity,
        description,
        reporterName: reporterName || 'Anonymous Citizen',
        reporterPhone: reporterPhone || 'Not provided'
      };

      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to submit report');
      }

      setSuccessMessage(
        'Hazard report submitted successfully! Status: PENDING_VERIFICATION. District Disaster Management officials have been notified.'
      );
      setLocationName('');
      setDistrict('');
      setDescription('');
      setReporterName('');
      setReporterPhone('');
      onSubmitSuccess();
    } catch (err: any) {
      setErrorMessage(err.message || 'Submission failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8 text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-1">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
          <Megaphone className="w-6 h-6 text-amber-400" />
          Citizen Ground-Observation Hazard Reporting
        </h1>
        <p className="text-xs text-slate-400">
          Report active ground fissures, sudden slope shifts, blocked stormwater culverts, or rising water levels
        </p>
      </div>

      {/* Strict Anti-Panic Integrity Notice */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-start gap-3 text-xs">
        <ShieldAlert className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <strong className="text-slate-200 block">Civil Defense Integrity Protocol:</strong>
          <p className="text-slate-400 leading-relaxed">
            All citizen submissions immediately enter a strict <strong className="text-amber-400 font-mono">PENDING_VERIFICATION</strong> status. Citizen reports do NOT immediately alter official public risk scores or polygon boundaries. They are reviewed and corroborated by district disaster authorities in the Admin Console to prevent false alarms.
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 p-6 rounded-xl shadow-lg space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Location / Landmark Name *</label>
            <input
              type="text"
              required
              value={locationName}
              onChange={e => setLocationName(e.target.value)}
              placeholder="e.g. Near Meppadi Tea Estate Bridge"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">State</label>
            <select
              value={stateName}
              onChange={e => setStateName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
            >
              <option value="Kerala">Kerala</option>
              <option value="Tamil Nadu">Tamil Nadu</option>
              <option value="Assam">Assam</option>
              <option value="Odisha">Odisha</option>
              <option value="Uttarakhand">Uttarakhand</option>
              <option value="Himachal Pradesh">Himachal Pradesh</option>
              <option value="Gujarat">Gujarat</option>
              <option value="Maharashtra">Maharashtra</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Latitude (°N) *</label>
            <input
              type="number"
              step="0.0001"
              required
              value={latitude}
              onChange={e => setLatitude(e.target.value)}
              placeholder="e.g. 11.5173"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Longitude (°E) *</label>
            <input
              type="number"
              step="0.0001"
              required
              value={longitude}
              onChange={e => setLongitude(e.target.value)}
              placeholder="e.g. 76.1368"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Hazard Category *</label>
            <select
              value={hazardType}
              onChange={e => setHazardType(e.target.value as HazardType)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
            >
              <option value="landslide">Landslide / Soil Subsidence / Rockfall</option>
              <option value="flood">Water Logging / Stream Inundation</option>
              <option value="cyclone">Cyclone Wind Damage / Sea Surge</option>
              <option value="earthquake">Structural Seismic Fissure</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Observed Severity</label>
            <select
              value={severity}
              onChange={e => setSeverity(e.target.value as RiskLevel)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
            >
              <option value="YELLOW">Moderate (Cracks appearing, drain overflow)</option>
              <option value="ORANGE">High (Continuous soil movement, water entering premises)</option>
              <option value="RED">Very High (Immediate danger to life / active slide)</option>
            </select>
          </div>
        </div>

        <div className="text-xs">
          <label className="text-slate-400 font-medium block mb-1">Detailed Description of Hazard Observation *</label>
          <textarea
            required
            rows={3}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Describe what you observed (e.g. 10cm ground fissure propagating across retaining wall following heavy night rain)..."
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Reporter Name (Optional)</label>
            <input
              type="text"
              value={reporterName}
              onChange={e => setReporterName(e.target.value)}
              placeholder="e.g. Anand Menon"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Contact Phone Number (Optional)</label>
            <input
              type="tel"
              value={reporterPhone}
              onChange={e => setReporterPhone(e.target.value)}
              placeholder="e.g. +91 98470 12345"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-500 disabled:bg-amber-800 text-white rounded-lg text-xs font-semibold shadow transition-colors cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>{isSubmitting ? 'Submitting to Verification Queue...' : 'Submit Official Hazard Report'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
