import React, { useState } from 'react';
import { History, Filter, Search, Calendar, MapPin, Database, ArrowUpRight } from 'lucide-react';
import { HistoricalEvent, HazardType } from '../types';

interface HistoricalHazardsPageProps {
  historicalEvents: HistoricalEvent[];
  onNavigateToMap: () => void;
}

export const HistoricalHazardsPage: React.FC<HistoricalHazardsPageProps> = ({
  historicalEvents,
  onNavigateToMap
}) => {
  const [hazardFilter, setHazardFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = historicalEvents.filter(e => {
    if (hazardFilter !== 'all' && e.hazard !== hazardFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = e.title.toLowerCase().includes(q) ||
        e.location.toLowerCase().includes(q) ||
        e.state.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-1">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
          <History className="w-6 h-6 text-emerald-400" />
          Verified Historical Multi-Hazard Inventories (1999 – 2024)
        </h1>
        <p className="text-xs text-slate-400">
          Peer-reviewed, ground-truth disaster occurrences sourced directly from Geological Survey of India (GSI), Central Water Commission (CWC), and IMD
        </p>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Hazard:</span>
            <select
              value={hazardFilter}
              onChange={e => setHazardFilter(e.target.value)}
              className="bg-slate-950 text-slate-200 px-2 py-1 rounded border border-slate-700 focus:outline-none"
            >
              <option value="all">All Multi-Hazards</option>
              <option value="landslide">Landslides (GSI Catalog)</option>
              <option value="flood">Floods (CWC Records)</option>
              <option value="cyclone">Cyclones (IMD e-Atlas)</option>
              <option value="earthquake">Earthquakes (USGS/NCS)</option>
            </select>
          </div>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by event, state, or location..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Historical Records Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(item => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition-all space-y-3 shadow-md"
          >
            <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-2.5">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {item.hazard}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {item.date}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white mt-1">{item.title}</h3>
                <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3 h-3 text-emerald-400" />
                  {item.location}, {item.state}
                </p>
              </div>

              <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded ${
                item.severity === 'RED' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'
              }`}>
                {item.severity}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {item.description}
            </p>

            {/* Impact Metric Tags */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] bg-slate-950 p-2 rounded-lg border border-slate-800">
              {item.fatalities && (
                <div>
                  <span className="text-[10px] text-slate-400 block">Fatalities</span>
                  <span className="font-mono font-bold text-rose-400">{item.fatalities.toLocaleString()}</span>
                </div>
              )}
              {item.rainfall_mm && (
                <div>
                  <span className="text-[10px] text-slate-400 block">Peak Rainfall</span>
                  <span className="font-mono font-bold text-blue-400">{item.rainfall_mm} mm</span>
                </div>
              )}
              {item.magnitude && (
                <div>
                  <span className="text-[10px] text-slate-400 block">Magnitude</span>
                  <span className="font-mono font-bold text-amber-400">M {item.magnitude}</span>
                </div>
              )}
              {item.economicLoss_cr && (
                <div>
                  <span className="text-[10px] text-slate-400 block">Est. Economic Loss</span>
                  <span className="font-mono font-bold text-slate-200">₹{item.economicLoss_cr} Cr</span>
                </div>
              )}
            </div>

            {/* Official Provenance */}
            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 font-mono">
              <span className="flex items-center gap-1">
                <Database className="w-3 h-3 text-slate-500" />
                Provenance: {item.source}
              </span>
              <span>Coords: {item.latitude}°N, {item.longitude}°E</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
