import React, { useState } from 'react';
import { Building2, MapPin, Navigation, Phone, CheckCircle, Search, ShieldCheck } from 'lucide-react';
import { RelocationSite, RiskZone } from '../types';
import { VERIFIED_RELOCATION_SITES } from '../data/verifiedData';
import { findNearestShelters } from '../services/dataOrchestrator';

interface RelocationSheltersPageProps {
  riskZones: RiskZone[];
}

export const RelocationSheltersPage: React.FC<RelocationSheltersPageProps> = ({ riskZones }) => {
  const [selectedZoneId, setSelectedZoneId] = useState<string>(riskZones[0]?.id || '');
  const [customLat, setCustomLat] = useState<string>('11.5173');
  const [customLon, setCustomLon] = useState<string>('76.1368');
  const [useCustomLocation, setUseCustomLocation] = useState<boolean>(false);

  const activeZone = riskZones.find(z => z.id === selectedZoneId) || riskZones[0];

  const targetLat = useCustomLocation ? parseFloat(customLat) || 11.5173 : activeZone?.coordinates[0] || 11.5173;
  const targetLon = useCustomLocation ? parseFloat(customLon) || 76.1368 : activeZone?.coordinates[1] || 76.1368;

  const nearestThree = findNearestShelters(targetLat, targetLon, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-1">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
          <Building2 className="w-6 h-6 text-emerald-400" />
          Emergency Relocation & Verified Evacuation Centres
        </h1>
        <p className="text-xs text-slate-400">
          Geospatial Haversine routing to SDMA-registered cyclone shelters, flood relief camps, and community safe havens
        </p>
      </div>

      {/* Target Hazard Zone Selector */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">Route From Disaster Location:</span>
            <select
              value={useCustomLocation ? 'custom' : selectedZoneId}
              onChange={e => {
                if (e.target.value === 'custom') {
                  setUseCustomLocation(true);
                } else {
                  setUseCustomLocation(false);
                  setSelectedZoneId(e.target.value);
                }
              }}
              className="bg-slate-950 border border-slate-700 text-slate-100 px-3 py-1.5 rounded-lg focus:outline-none focus:border-emerald-500"
            >
              {riskZones.map(z => (
                <option key={z.id} value={z.id}>
                  {z.name} ({z.state}) — {z.hazardType.toUpperCase()}
                </option>
              ))}
              <option value="custom">+ Enter Custom Coordinates in India</option>
            </select>
          </div>

          {useCustomLocation && (
            <div className="flex items-center gap-2">
              <input
                type="number"
                step="0.0001"
                placeholder="Lat"
                value={customLat}
                onChange={e => setCustomLat(e.target.value)}
                className="w-24 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 font-mono text-xs"
              />
              <input
                type="number"
                step="0.0001"
                placeholder="Lon"
                value={customLon}
                onChange={e => setCustomLon(e.target.value)}
                className="w-24 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-slate-100 font-mono text-xs"
              />
            </div>
          )}
        </div>
      </div>

      {/* Nearest 3 Shelters Feature Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Navigation className="w-4 h-4 text-emerald-400" />
            Nearest 3 Verified Shelters (Calculated via Haversine Distance)
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            Origin: {targetLat.toFixed(4)}°N, {targetLon.toFixed(4)}°E
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {nearestThree.map((site: RelocationSite, index: number) => (
            <div
              key={site.id}
              className="bg-slate-900 border border-slate-800 hover:border-emerald-600/50 p-5 rounded-xl transition-all space-y-3 shadow-lg relative overflow-hidden"
            >
              <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-400 font-mono font-bold text-[10px] flex items-center justify-center">
                      #{index + 1}
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      {site.distanceKm} km away
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white mt-1.5 leading-snug">{site.name}</h3>
                  <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    {site.address}
                  </p>
                </div>

                <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded shrink-0 ${
                  site.status === 'READY'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {site.status}
                </span>
              </div>

              {/* Occupancy and Capacity */}
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                  <span>Occupancy: {site.currentOccupancy} / {site.capacity}</span>
                  <span className="font-mono text-slate-300">
                    {Math.round((site.currentOccupancy / site.capacity) * 100)}%
                  </span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all"
                    style={{ width: `${Math.min(100, (site.currentOccupancy / site.capacity) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Verified Amenities Chips */}
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-semibold uppercase block">Verified Facilities</span>
                <div className="flex flex-wrap gap-1">
                  {site.amenities.map((a: string, i: number) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 bg-slate-950 text-slate-300 rounded border border-slate-800">
                      {a}
                    </span>
                  ))}
                </div>
              </div>

              {/* Contact Officer Details */}
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[11px] space-y-1">
                <div className="text-slate-400">
                  Officer: <strong className="text-slate-200">{site.contactPerson}</strong>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-400 font-mono">
                  <Phone className="w-3 h-3" />
                  <span>{site.contactPhone}</span>
                </div>
                <div className="text-[10px] text-slate-400 pt-0.5 border-t border-slate-900">
                  Last Inspected: {site.lastInspected || site.lastInspectionDate || 'Verified 2025'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Complete State Shelter Directory */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white">Full SDMA Emergency Shelter Registry</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">Shelter Name</th>
                <th className="p-3">State</th>
                <th className="p-3">Type</th>
                <th className="p-3">Capacity</th>
                <th className="p-3">Occupancy</th>
                <th className="p-3">Status</th>
                <th className="p-3">Officer & Contact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {VERIFIED_RELOCATION_SITES.map(s => (
                <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-semibold text-white">
                    {s.name}
                    <span className="block text-[10px] text-slate-400 font-normal">{s.address}</span>
                  </td>
                  <td className="p-3">{s.state}</td>
                  <td className="p-3 uppercase text-[10px] font-mono">{s.type.replace('_', ' ')}</td>
                  <td className="p-3 font-mono">{s.capacity}</td>
                  <td className="p-3 font-mono">{s.currentOccupancy}</td>
                  <td className="p-3">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {s.status}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="text-slate-200 block">{s.contactPerson}</span>
                    <span className="text-emerald-400 font-mono text-[10px]">{s.contactPhone}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
