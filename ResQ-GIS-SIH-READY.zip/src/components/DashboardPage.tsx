import React from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  Users,
  Map as MapIcon,
  Activity,
  ArrowRight,
  TrendingUp,
  CloudRain,
  Compass,
  Cpu
} from 'lucide-react';
import { RiskZone, AlertItem, HistoricalEvent } from '../types';

interface DashboardPageProps {
  riskZones: RiskZone[];
  activeAlerts: AlertItem[];
  historicalEvents: HistoricalEvent[];
  onNavigate: (page: string) => void;
  onSelectZoneForAI: (zone: RiskZone) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  riskZones,
  activeAlerts,
  historicalEvents,
  onNavigate,
  onSelectZoneForAI
}) => {
  const redZones = riskZones.filter(z => z.currentRisk === 'RED');
  const orangeZones = riskZones.filter(z => z.currentRisk === 'ORANGE');
  const yellowZones = riskZones.filter(z => z.currentRisk === 'YELLOW');

  const totalExposedPop = riskZones.reduce((acc, z) => acc + z.populationExposed.total, 0);
  const totalRedPop = riskZones.reduce((acc, z) => acc + z.populationExposed.red, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100">
      {/* Header Overview Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Activity className="w-5 h-5 text-emerald-400" />
            National Disaster Risk & Multi-Hazard Overview
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time synoptic intelligence coupled with Open-Meteo atmospheric forecasts and Copernicus 30m terrain models
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('map')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow transition-colors cursor-pointer"
          >
            <MapIcon className="w-3.5 h-3.5" />
            <span>Open GIS Map</span>
          </button>
          <button
            onClick={() => onNavigate('alerts')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            <span>View All Alerts</span>
          </button>
        </div>
      </div>

      {/* Top Level Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Red Very High Risk */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Very High Risk Areas</span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400">{redZones.length}</div>
          <p className="text-[11px] text-slate-400">Immediate evacuation vigilance</p>
        </div>

        {/* Orange High Risk */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>High Risk Watch</span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">{orangeZones.length}</div>
          <p className="text-[11px] text-slate-400">Active monitoring of triggers</p>
        </div>

        {/* Moderate Risk */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Moderate Advisory</span>
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400"></span>
          </div>
          <div className="text-2xl font-bold font-mono text-yellow-400">{yellowZones.length}</div>
          <p className="text-[11px] text-slate-400">Prepositioning civic assets</p>
        </div>

        {/* Population Exposed */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Population at Risk</span>
            <Users className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-300">
            {(totalExposedPop / 1000).toFixed(1)}k
          </div>
          <p className="text-[11px] text-slate-400">
            {(totalRedPop / 1000).toFixed(1)}k in high-severity sectors
          </p>
        </div>
      </div>

      {/* Two Column Layout: Active Risk Zones & Recent Events */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Monitored Risk Zones */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
              <Compass className="w-4 h-4 text-emerald-400" />
              Active Monitored Risk Zones Across India
            </h2>
            <button
              onClick={() => onNavigate('map')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>View On Map</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3">
            {riskZones.map(zone => (
              <div
                key={zone.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-xl transition-all space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase tracking-wider font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {zone.hazardType}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        zone.currentRisk === 'RED'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : zone.currentRisk === 'ORANGE'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-yellow-950 text-yellow-300 border border-yellow-800'
                      }`}>
                        Current: {zone.currentRisk} ({zone.currentScore}/100)
                      </span>
                      <span className="text-[10px] text-slate-400 hidden sm:inline">
                        Historical: <strong className="text-slate-300">{zone.historicalSusceptibility}</strong>
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-100 mt-1">{zone.name}</h3>
                    <p className="text-xs text-slate-400">{zone.district}, {zone.state}</p>
                  </div>

                  <button
                    onClick={() => onSelectZoneForAI(zone)}
                    className="self-start sm:self-center flex items-center gap-1.5 px-3 py-1.5 bg-blue-900/40 hover:bg-blue-800/60 border border-blue-700 text-blue-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <Cpu className="w-3.5 h-3.5 text-blue-400" />
                    <span>Run AI Analysis</span>
                  </button>
                </div>

                {/* Evidence Metrics Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/80">
                  <div>
                    <span className="text-[10px] text-slate-400 block">24h Rainfall</span>
                    <span className="font-mono font-semibold text-slate-200">{zone.currentConditions.rainfall24h_mm} mm</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">3d Cumulative</span>
                    <span className="font-mono font-semibold text-slate-200">{zone.currentConditions.rainfall3d_mm} mm</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Terrain Slope</span>
                    <span className="font-mono font-semibold text-slate-200">{zone.currentConditions.slope_deg}°</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Population</span>
                    <span className="font-mono font-semibold text-slate-200">{zone.populationExposed.total.toLocaleString()}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  <strong className="text-slate-200">AI Assessment:</strong> {zone.aiExplanation}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Right 1 Col: Severe Weather & Recent Historical Feed */}
        <div className="space-y-6">
          {/* Active Warnings Alert Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                Active Early Warnings ({activeAlerts.length})
              </h3>
              <button
                onClick={() => onNavigate('alerts')}
                className="text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                View Feed →
              </button>
            </div>

            <div className="space-y-2.5">
              {activeAlerts.slice(0, 3).map(alert => (
                <div key={alert.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-200 uppercase font-mono">{alert.hazard}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      alert.severity === 'RED' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'
                    }`}>
                      {alert.severity}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-slate-200">{alert.location}</p>
                  <p className="text-[11px] text-slate-400 line-clamp-2">{alert.reason}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Historical Hotspot Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                Historical Event Records
              </h3>
              <button
                onClick={() => onNavigate('historical')}
                className="text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Catalog →
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              {historicalEvents.slice(0, 4).map(e => (
                <div key={e.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>{e.date}</span>
                    <span className="uppercase font-mono text-emerald-400">{e.hazard}</span>
                  </div>
                  <h4 className="font-semibold text-slate-200 text-xs">{e.title}</h4>
                  <p className="text-[11px] text-slate-400 line-clamp-2">{e.description}</p>
                  <div className="text-[10px] text-slate-400 pt-0.5">
                    Source: {e.source}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
