import React from 'react';
import { Users, ShieldAlert, Layers, MapPin, Info, ArrowUpRight, BarChart3 } from 'lucide-react';
import { RiskZone } from '../types';

interface PopulationAtRiskPageProps {
  riskZones: RiskZone[];
}

export const PopulationAtRiskPage: React.FC<PopulationAtRiskPageProps> = ({ riskZones }) => {
  const totalExposed = riskZones.reduce((acc, z) => acc + z.populationExposed.total, 0);
  const redExposed = riskZones.reduce((acc, z) => acc + z.populationExposed.red, 0);
  const orangeExposed = riskZones.reduce((acc, z) => acc + z.populationExposed.orange, 0);
  const yellowExposed = riskZones.reduce((acc, z) => acc + z.populationExposed.yellow, 0);
  const totalAreaSqKm = riskZones.reduce((acc, z) => acc + (z.populationExposed.area_sqkm || 450), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-1">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
          <Users className="w-6 h-6 text-indigo-400" />
          Demographic Exposure & Population-at-Risk Engine
        </h1>
        <p className="text-xs text-slate-400">
          Spatially intersected 1km² WorldPop demographic raster cells within active hazard impact polygons across India
        </p>
      </div>

      {/* Aggregate Zonal Metrics Banner */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 block">Total Population Exposed</span>
          <span className="text-2xl font-bold font-mono text-white">{(totalExposed / 1000).toFixed(1)}k</span>
          <span className="text-[11px] text-slate-400 block">Across sovereign sectors</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-rose-400 block font-semibold">Red Zone (Immediate Evac)</span>
          <span className="text-2xl font-bold font-mono text-rose-400">{(redExposed / 1000).toFixed(1)}k</span>
          <span className="text-[11px] text-slate-400 block">Severe trigger footprint</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-amber-400 block font-semibold">Orange Zone (High Watch)</span>
          <span className="text-2xl font-bold font-mono text-amber-400">{(orangeExposed / 1000).toFixed(1)}k</span>
          <span className="text-[11px] text-slate-400 block">Adjoining buffer corridors</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-yellow-400 block font-semibold">Yellow Zone (Advisory)</span>
          <span className="text-2xl font-bold font-mono text-yellow-400">{(yellowExposed / 1000).toFixed(1)}k</span>
          <span className="text-[11px] text-slate-400 block">Secondary drainage basins</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1 col-span-2 lg:col-span-1">
          <span className="text-xs text-slate-400 block">Footprint Area</span>
          <span className="text-2xl font-bold font-mono text-emerald-400">{totalAreaSqKm.toFixed(0)} km²</span>
          <span className="text-[11px] text-slate-400 block">Calculated spatial envelope</span>
        </div>
      </div>

      {/* Scientific Methodology Explanation Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Info className="w-4 h-4 text-indigo-400" />
          Why ResQ-GIS Rejects Flat District-Census Aggregates
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          Standard disaster portals frequently quote entire district populations (e.g., claiming 800,000 people are at risk simply because a landslide occurred in Wayanad district). This creates severe operational misallocation of relief resources.
          ResQ-GIS performs <strong className="text-white">Spatial Polygon Vector-Raster Zonal Intersection</strong>:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <strong className="text-slate-200 block mb-1">1. 30-Metre DEM Extraction</strong>
            <span className="text-slate-400">Delineates slope runout paths and hydraulic inundation contours rather than political boundaries.</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <strong className="text-slate-200 block mb-1">2. WorldPop 1km² Grids</strong>
            <span className="text-slate-400">Extracts unconstrained settlement density rasters calibrated with latest Census of India projections.</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <strong className="text-slate-200 block mb-1">3. Zonal Hazard Buffering</strong>
            <span className="text-slate-400">Classifies population into Red (&ge;75 score), Orange (55-74), and Yellow (35-54) evacuation cohorts.</span>
          </div>
        </div>
      </div>

      {/* Zonal Breakdown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white">Active Hazard Footprint Demographic Breakdown</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="p-3">Risk Zone & State</th>
                <th className="p-3">Hazard</th>
                <th className="p-3">Severity</th>
                <th className="p-3">Footprint (km²)</th>
                <th className="p-3 text-rose-400">Red Zone Pop</th>
                <th className="p-3 text-amber-400">Orange Zone Pop</th>
                <th className="p-3 text-yellow-400">Yellow Zone Pop</th>
                <th className="p-3 font-bold text-white">Total Exposed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {riskZones.map(zone => (
                <tr key={zone.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-sans font-medium text-white">
                    {zone.name}
                    <span className="block text-[10px] text-slate-400 font-normal">{zone.district}, {zone.state}</span>
                  </td>
                  <td className="p-3 uppercase">{zone.hazardType}</td>
                  <td className="p-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      zone.currentRisk === 'RED' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'
                    }`}>
                      {zone.currentRisk}
                    </span>
                  </td>
                  <td className="p-3">{zone.populationExposed.area_sqkm || 450} km²</td>
                  <td className="p-3 text-rose-400 font-bold">{zone.populationExposed.red.toLocaleString()}</td>
                  <td className="p-3 text-amber-400">{zone.populationExposed.orange.toLocaleString()}</td>
                  <td className="p-3 text-yellow-400">{zone.populationExposed.yellow.toLocaleString()}</td>
                  <td className="p-3 font-bold text-white font-sans">{zone.populationExposed.total.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
