import React, { useState, useEffect } from 'react';
import {
  Settings,
  CheckCircle,
  XCircle,
  RefreshCw,
  Server,
  Building2,
  FileCheck,
  AlertTriangle,
  Clock,
  Database
} from 'lucide-react';
import { CitizenHazardReport, RelocationSite } from '../types';

export const AdminPanelPage: React.FC = () => {
  const [reports, setReports] = useState<CitizenHazardReport[]>([]);
  const [systemStatus, setSystemStatus] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // New shelter form state
  const [newShelterName, setNewShelterName] = useState('');
  const [newShelterState, setNewShelterState] = useState('Kerala');
  const [newShelterLat, setNewShelterLat] = useState('');
  const [newShelterLon, setNewShelterLon] = useState('');
  const [newShelterCapacity, setNewShelterCapacity] = useState('500');
  const [newShelterContact, setNewShelterContact] = useState('');
  const [newShelterPhone, setNewShelterPhone] = useState('');

  const fetchAdminData = async () => {
    try {
      const [reportsRes, statusRes] = await Promise.all([
        fetch('/api/admin/reports'),
        fetch('/api/admin/system-status')
      ]);
      if (reportsRes.ok) {
        const rData = await reportsRes.json();
        setReports(rData.reports || []);
      }
      if (statusRes.ok) {
        const sData = await statusRes.json();
        setSystemStatus(sData);
      }
    } catch (err) {
      console.error('Failed to fetch admin telemetry', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleApproveReport = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/reports/${id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminNotes: 'Verified via ground officer inspection' })
      });
      if (res.ok) {
        setActionMessage(`Report ${id} approved.`);
        fetchAdminData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRejectReport = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/reports/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminNotes: 'Unsubstantiated / false alarm' })
      });
      if (res.ok) {
        setActionMessage(`Report ${id} rejected.`);
        fetchAdminData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRefreshCache = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/admin/refresh-data', { method: 'POST' });
      if (res.ok) {
        setActionMessage('Data cache successfully cleared and re-synced.');
        fetchAdminData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleAddShelter = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        name: newShelterName,
        state: newShelterState,
        coordinates: [parseFloat(newShelterLat), parseFloat(newShelterLon)],
        capacity: parseInt(newShelterCapacity) || 400,
        contactPerson: newShelterContact,
        contactPhone: newShelterPhone
      };
      const res = await fetch('/api/admin/relocation-sites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setActionMessage('New emergency shelter added to directory.');
        setNewShelterName('');
        setNewShelterLat('');
        setNewShelterLon('');
        setNewShelterContact('');
        setNewShelterPhone('');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <Settings className="w-6 h-6 text-slate-300" />
            ResQ-GIS Administrative & Verification Console
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Official dashboard for reviewing citizen hazard reports, managing emergency shelters, and auditing API telemetry
          </p>
        </div>

        <button
          onClick={handleRefreshCache}
          disabled={isRefreshing}
          className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold shadow transition-colors cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
          <span>{isRefreshing ? 'Re-Syncing Live Data...' : 'Manual Live Data Re-Sync'}</span>
        </button>
      </div>

      {actionMessage && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-800 rounded-lg text-emerald-300 text-xs flex items-center justify-between">
          <span>{actionMessage}</span>
          <button onClick={() => setActionMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* System Health Telemetry */}
      {systemStatus && (
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-md">
          <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Server className="w-4 h-4 text-emerald-400" />
            Live Backend Telemetry & Sensor Health
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Open-Meteo Weather API</span>
              <span className="font-mono font-bold text-emerald-400 flex items-center gap-1 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                {systemStatus.apis?.openMeteo?.status || 'ONLINE'}
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block">USGS Seismic Feed</span>
              <span className="font-mono font-bold text-emerald-400 flex items-center gap-1 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                {systemStatus.apis?.usgsEarthquakes?.status || 'ONLINE'}
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Copernicus 30m DEM</span>
              <span className="font-mono font-bold text-emerald-400 flex items-center gap-1 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                {systemStatus.apis?.copernicusDem?.status || 'ONLINE'}
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Server In-Memory Cache</span>
              <span className="font-mono font-bold text-slate-200 mt-0.5 block">
                {systemStatus.server?.cachedWeatherEntries} entries
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Citizen Hazard Verification Queue */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-md">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-amber-400" />
            Citizen Hazard Observation Queue ({reports.length})
          </h2>
          <span className="text-xs text-slate-400">Review ground observations before GIS layer promotion</span>
        </div>

        {reports.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">No citizen reports in queue.</div>
        ) : (
          <div className="space-y-3">
            {reports.map(report => (
              <div
                key={report.id}
                className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 text-xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900 pb-2.5">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {report.hazardType}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        report.severity === 'RED' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'
                      }`}>
                        {report.severity}
                      </span>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        report.status === 'VERIFIED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : report.status === 'REJECTED'
                          ? 'bg-rose-950 text-rose-300'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        STATUS: {report.status}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white mt-1">{report.locationName}</h3>
                    <p className="text-[11px] text-slate-400">
                      {report.district}, {report.state} • Coords: {report.latitude}°N, {report.longitude}°E
                    </p>
                  </div>

                  <div className="text-[10px] text-slate-400 font-mono">
                    Reported by: <strong className="text-slate-200">{report.reporterName}</strong> ({report.reporterContact || report.reporterPhone || 'N/A'})
                  </div>
                </div>

                <p className="text-slate-300 leading-relaxed bg-slate-900/50 p-2.5 rounded border border-slate-900">
                  {report.description}
                </p>

                {report.status === 'PENDING_VERIFICATION' && (
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => handleRejectReport(report.id)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800 rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject (False Alarm)</span>
                    </button>
                    <button
                      onClick={() => handleApproveReport(report.id)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow cursor-pointer"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Approve & Promote to GIS Layer</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add New Emergency Shelter Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-md">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Building2 className="w-4 h-4 text-emerald-400" />
          Register New Verified Disaster Shelter
        </h2>

        <form onSubmit={handleAddShelter} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">Shelter Name *</label>
            <input
              type="text"
              required
              value={newShelterName}
              onChange={e => setNewShelterName(e.target.value)}
              placeholder="e.g. Kozhikode Coastal Relief Centre"
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Latitude (°N) *</label>
            <input
              type="number"
              step="0.0001"
              required
              value={newShelterLat}
              onChange={e => setNewShelterLat(e.target.value)}
              placeholder="e.g. 11.2588"
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Longitude (°E) *</label>
            <input
              type="number"
              step="0.0001"
              required
              value={newShelterLon}
              onChange={e => setNewShelterLon(e.target.value)}
              placeholder="e.g. 75.7804"
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Capacity (Persons)</label>
            <input
              type="number"
              value={newShelterCapacity}
              onChange={e => setNewShelterCapacity(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Nodal Officer Name</label>
            <input
              type="text"
              value={newShelterContact}
              onChange={e => setNewShelterContact(e.target.value)}
              placeholder="e.g. District Tahsildar"
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Contact Phone</label>
            <input
              type="tel"
              value={newShelterPhone}
              onChange={e => setNewShelterPhone(e.target.value)}
              placeholder="e.g. +91 495 2371234"
              className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-slate-100 font-mono"
            />
          </div>

          <div className="sm:col-span-3 flex justify-end pt-1">
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              Add Verified Shelter to Directory
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
