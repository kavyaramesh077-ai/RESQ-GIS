import React, { useState } from 'react';
import {
  Cpu,
  Search,
  MapPin,
  Sparkles,
  Layers,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Building2,
  ExternalLink,
  Info,
  Clock
} from 'lucide-react';
import { HazardType, AIRiskAnalysisResult, RiskZone } from '../types';
import { analyzeLocationRisk } from '../services/dataOrchestrator';
import { isPointInIndia, getIndiaSpatialValidation } from '../data/indiaBoundary';

interface AIRiskAnalyzerPageProps {
  initialZone?: RiskZone | null;
  onNavigateToShelters: () => void;
}

export const AIRiskAnalyzerPage: React.FC<AIRiskAnalyzerPageProps> = ({
  initialZone,
  onNavigateToShelters
}) => {
  const [latInput, setLatInput] = useState<string>(
    initialZone ? initialZone.coordinates[0].toString() : '11.5173'
  );
  const [lonInput, setLonInput] = useState<string>(
    initialZone ? initialZone.coordinates[1].toString() : '76.1368'
  );
  const [selectedHazard, setSelectedHazard] = useState<HazardType>(
    initialZone ? initialZone.hazardType : 'landslide'
  );
  const [locationName, setLocationName] = useState<string>(
    initialZone ? initialZone.name : 'Wayanad Meppadi Hill Tract'
  );

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<AIRiskAnalysisResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Quick preset locations in India
  const presetLocations = [
    { name: 'Wayanad, Kerala (Mountain Debris Flow)', lat: 11.5173, lon: 76.1368, hazard: 'landslide' as HazardType },
    { name: 'Munnar, Idukki, Kerala (High Slope Escarpment)', lat: 10.0889, lon: 77.0595, hazard: 'landslide' as HazardType },
    { name: 'Chennai, Tamil Nadu (Low-Lying Urban Basin)', lat: 13.0827, lon: 80.2707, hazard: 'flood' as HazardType },
    { name: 'Barpeta, Assam (Brahmaputra Riparian Plain)', lat: 26.3214, lon: 91.0062, hazard: 'flood' as HazardType },
    { name: 'Puri, Odisha (Coastal Cyclone Corridor)', lat: 19.8135, lon: 85.8312, hazard: 'cyclone' as HazardType },
    { name: 'Chamoli, Uttarakhand (Himalayan Seismic Belt)', lat: 30.4070, lon: 79.4180, hazard: 'earthquake' as HazardType }
  ];

  const handleRunAnalysis = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const lat = parseFloat(latInput);
    const lon = parseFloat(lonInput);

    if (isNaN(lat) || isNaN(lon)) {
      setErrorMessage('Please enter valid numerical latitude and longitude coordinates.');
      return;
    }

    // Strict India sovereign check
    const validation = getIndiaSpatialValidation(lat, lon);
    if (!validation.isValid) {
      setErrorMessage(validation.message);
      return;
    }

    setIsLoading(true);
    try {
      const res = await analyzeLocationRisk(lat, lon, selectedHazard, locationName);
      setAnalysisResult(res);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete AI Risk Analysis.');
    } finally {
      setIsLoading(false);
    }
  };

  const applyPreset = (preset: typeof presetLocations[0]) => {
    setLatInput(preset.lat.toString());
    setLonInput(preset.lon.toString());
    setSelectedHazard(preset.hazard);
    setLocationName(preset.name.split('(')[0].trim());
    setErrorMessage(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-100">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5 space-y-1">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
          <Cpu className="w-6 h-6 text-blue-400" />
          AI Risk Analyzer & Hybrid Deep Learning Inference
        </h1>
        <p className="text-xs text-slate-400">
          Coupled multi-scale spatial CNN, temporal LSTM sequence models, and physical hydrodynamic equations for any coordinate in India
        </p>
      </div>

      {/* Preset Quick Selectors */}
      <div className="space-y-2">
        <span className="text-xs font-semibold text-slate-400">Sample Indian Hazard Corridors:</span>
        <div className="flex flex-wrap gap-2">
          {presetLocations.map(p => (
            <button
              key={p.name}
              type="button"
              onClick={() => applyPreset(p)}
              className="text-xs px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Query Form */}
      <form onSubmit={handleRunAnalysis} className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Location / Sector Name</label>
            <input
              type="text"
              value={locationName}
              onChange={e => setLocationName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
              placeholder="e.g. Munnar Ghat Sector"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Latitude (°N)</label>
            <input
              type="number"
              step="0.0001"
              value={latInput}
              onChange={e => setLatInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              placeholder="e.g. 10.0889"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Longitude (°E)</label>
            <input
              type="number"
              step="0.0001"
              value={lonInput}
              onChange={e => setLonInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-blue-500"
              placeholder="e.g. 77.0595"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Target Hazard</label>
            <select
              value={selectedHazard}
              onChange={e => setSelectedHazard(e.target.value as HazardType)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-blue-500"
            >
              <option value="landslide">Landslide (Hill Escarpment)</option>
              <option value="flood">Flood (Basin Inundation)</option>
              <option value="cyclone">Cyclone (Coastal Surge)</option>
              <option value="earthquake">Earthquake (Seismic PGA)</option>
            </select>
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isLoading}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white rounded-lg text-xs font-semibold shadow-md transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isLoading ? 'Querying Atmospheric & Terrain Sensors...' : 'Run AI Multi-Hazard Analysis'}</span>
          </button>
        </div>
      </form>

      {/* Analysis Results Display */}
      {analysisResult && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
          {/* Top Score Banner */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded ${
                    analysisResult.aiRiskLevel === 'RED'
                      ? 'bg-rose-600 text-white'
                      : analysisResult.aiRiskLevel === 'ORANGE'
                      ? 'bg-amber-600 text-white'
                      : 'bg-yellow-500 text-slate-950'
                  }`}>
                    {analysisResult.aiRiskLevel} — RISK SCORE: {analysisResult.riskScore}/100
                  </span>
                  <span className="text-xs font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {analysisResult.hazardType}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white mt-1 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  {analysisResult.location.name}
                  <span className="text-xs font-normal text-slate-400 font-mono">
                    ({analysisResult.location.latitude.toFixed(4)}°N, {analysisResult.location.longitude.toFixed(4)}°E)
                  </span>
                </h2>
              </div>

              <div className="text-left sm:text-right text-xs font-mono space-y-1">
                <div className="text-slate-400">
                  Historical Susceptibility: <strong className="text-slate-200">{analysisResult.historicalSusceptibility} ({analysisResult.historicalScore}/100)</strong>
                </div>
                <div className="text-slate-400">
                  Ensemble Confidence: <strong className="text-emerald-400 font-bold">{Math.round(analysisResult.modelInference.ensembleConfidence * 100)}%</strong>
                </div>
              </div>
            </div>

            {/* Model Architecture Inference Scores */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">ResQ-Spatial-CNN Score</span>
                <span className="text-xl font-bold font-mono text-blue-400">{analysisResult.modelInference.cnnSpatialScore}/100</span>
                <p className="text-[10px] text-slate-400">Multi-scale 2D terrain slope & elevation gradient</p>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">ResQ-Hydro-LSTM Score</span>
                <span className="text-xl font-bold font-mono text-emerald-400">{analysisResult.modelInference.lstmSequenceScore}/100</span>
                <p className="text-[10px] text-slate-400">7-day hydro-meteorological antecedent accumulation</p>
              </div>

              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">ResNet-50 Vision Feature Extractor</span>
                <span className="text-xs font-bold text-slate-300 block">{analysisResult.modelInference.resnetFeatureStatus}</span>
                <p className="text-[10px] text-slate-400">Validated on Sentinel-2 optical multi-spectral bands</p>
              </div>
            </div>
          </div>

          {/* Current Conditions vs Historical Evidence */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Live Environmental Metrics */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                Live Atmospheric & Terrain Telemetry
              </h3>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">24h Rainfall</span>
                  <span className="font-mono font-bold text-slate-100">{analysisResult.currentConditions.rainfall24h_mm} mm</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">3-Day Rainfall Accumulation</span>
                  <span className="font-mono font-bold text-slate-100">{analysisResult.currentConditions.rainfall3d_mm} mm</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">7-Day Rainfall Total</span>
                  <span className="font-mono font-bold text-slate-100">{analysisResult.currentConditions.rainfall7d_mm} mm</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Soil Moisture Saturation</span>
                  <span className="font-mono font-bold text-slate-100">{analysisResult.currentConditions.soilMoisture_percent}%</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Copernicus 30m Elevation</span>
                  <span className="font-mono font-bold text-slate-100">{analysisResult.currentConditions.elevation_m} m</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Terrain Slope Angle</span>
                  <span className="font-mono font-bold text-slate-100">{analysisResult.currentConditions.slope_deg}°</span>
                </div>
              </div>
            </div>

            {/* Historical Evidence & Population */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-400" />
                Historical Evidence & Population Exposure
              </h3>

              <div className="space-y-2 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block">Verified Past Events in Vicinity</span>
                  <p className="text-slate-200">
                    <strong className="text-emerald-400 font-mono font-bold">{analysisResult.historicalEvidence.nearbyHistoricalEventsCount}</strong> past documented events within 140km.
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Latest Event: {analysisResult.historicalEvidence.latestEventDate} ({analysisResult.historicalEvidence.latestEventTitle})
                  </p>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block">WorldPop Gridded Population Exposure</span>
                  <p className="text-slate-200 font-mono">
                    Total Exposed: <strong className="text-white font-bold">{analysisResult.populationExposed.totalAtRisk.toLocaleString()}</strong>
                  </p>
                  <div className="flex gap-2 text-[10px] text-slate-400 font-mono pt-1">
                    <span className="text-rose-400 font-semibold">Red: {analysisResult.populationExposed.redZone.toLocaleString()}</span>
                    <span>•</span>
                    <span className="text-amber-400 font-semibold">Orange: {analysisResult.populationExposed.orangeZone.toLocaleString()}</span>
                    <span>•</span>
                    <span className="text-yellow-400 font-semibold">Yellow: {analysisResult.populationExposed.yellowZone.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Explainable AI Causal Analysis & Action */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-400" />
                Evidence-Based AI Explanation: WHY This Location is at Risk
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                {analysisResult.aiExplanation}
              </p>
            </div>

            <div className="space-y-1">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                Recommended Civil Defense Action
              </h4>
              <p className="text-xs text-emerald-200 leading-relaxed bg-emerald-950/30 p-3.5 rounded-lg border border-emerald-900/50">
                {analysisResult.recommendedAction}
              </p>
            </div>
          </div>

          {/* Nearest 3 Verified Relocation Shelters */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                Nearest 3 Verified Emergency Evacuation Shelters
              </h3>
              <button
                onClick={onNavigateToShelters}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
              >
                View Directory →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              {analysisResult.nearestShelters.map((sh, idx) => (
                <div key={sh.id} className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-emerald-400">
                      #{idx + 1} • {sh.distanceKm} km
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 uppercase">
                      {sh.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-100 text-xs">{sh.name}</h4>
                  <p className="text-[11px] text-slate-400">{sh.address}</p>
                  <div className="text-[11px] text-slate-300 pt-1 border-t border-slate-900 font-mono">
                    Capacity: <strong>{sh.capacity} persons</strong>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Contact: {sh.contactPerson} ({sh.contactPhone})
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Scientific Provenance Table */}
          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl space-y-2 text-xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Dataset Provenance & Observation Timestamps (Zero Fake Data Guarantee)
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[11px] text-slate-400 font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-300">
                    <th className="pb-1">Variable</th>
                    <th className="pb-1">Source / Dataset</th>
                    <th className="pb-1">Resolution</th>
                    <th className="pb-1">Observation Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {analysisResult.provenance.map((p, i) => (
                    <tr key={i}>
                      <td className="py-1 text-slate-200">{p.variable}</td>
                      <td className="py-1">{p.source}</td>
                      <td className="py-1">{p.resolution || 'N/A'}</td>
                      <td className="py-1">{p.observationDate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
