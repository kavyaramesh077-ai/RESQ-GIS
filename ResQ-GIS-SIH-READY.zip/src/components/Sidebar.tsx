import React from 'react';
import {
  Home,
  LayoutDashboard,
  Bell,
  Map as MapIcon,
  Cpu,
  History,
  Users,
  Building2,
  Megaphone,
  Settings,
  ShieldCheck
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  redAlertCount: number;
  pendingReportsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  redAlertCount,
  pendingReportsCount
}) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home, badge: null },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'alerts', label: 'Live Alerts', icon: Bell, badge: redAlertCount > 0 ? `${redAlertCount} RED` : null, badgeColor: 'bg-rose-600 text-white' },
    { id: 'map', label: 'GIS Map', icon: MapIcon, badge: 'Live GIS', badgeColor: 'bg-emerald-900 text-emerald-300 border border-emerald-700' },
    { id: 'ai-analyzer', label: 'AI Risk Analyzer', icon: Cpu, badge: 'CNN/LSTM', badgeColor: 'bg-blue-900 text-blue-300' },
    { id: 'historical', label: 'Historical Hazards', icon: History, badge: '25 yrs', badgeColor: 'bg-slate-800 text-slate-300' },
    { id: 'population', label: 'Population at Risk', icon: Users, badge: 'WorldPop', badgeColor: 'bg-indigo-900 text-indigo-300' },
    { id: 'relocation', label: 'Relocation & Shelters', icon: Building2, badge: 'Nearest 3', badgeColor: 'bg-emerald-950 text-emerald-400' },
    { id: 'report', label: 'Report a Hazard', icon: Megaphone, badge: null },
    { id: 'admin', label: 'Admin Panel', icon: Settings, badge: pendingReportsCount > 0 ? `${pendingReportsCount} pending` : null, badgeColor: 'bg-amber-600 text-white' }
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none">
      <div className="p-4 space-y-1 overflow-y-auto">
        <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          Navigation
        </div>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-emerald-600/15 text-emerald-400 border border-emerald-600/30 font-semibold'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-slate-100 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Sovereign India Verification Footnote */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/50">
        <div className="flex items-start gap-2 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-slate-300">Geospatial Integrity</p>
            <p className="text-[10px] leading-tight text-slate-400">
              Clipped strictly to India sovereign territory via Ray-Casting PIP. Zero fake data.
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
};
