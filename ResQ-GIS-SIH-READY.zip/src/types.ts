// ResQ-GIS Core TypeScript Definitions

export type HazardType = 
  | 'flood'
  | 'landslide'
  | 'cyclone'
  | 'earthquake'
  | 'forest_fire'
  | 'extreme_rainfall'
  | 'drought'
  | 'heat_wave'
  | 'coastal_hazard'
  | 'severe_storm';

export type RiskLevel = 'RED' | 'ORANGE' | 'YELLOW' | 'GREEN';

export interface Provenance {
  source: string;
  datasetName: string;
  url: string;
  timestamp: string;
  observationDate: string;
  variable: string;
  unit: string;
  resolution?: string;
  processingMethod: string;
}

export interface RiskZone {
  id: string;
  name: string;
  state: string;
  district: string;
  hazardType: HazardType;
  coordinates: [number, number]; // [lat, lon]
  boundaryPolygon?: [number, number][]; // Spatial polygon for GIS rendering
  historicalSusceptibility: RiskLevel;
  historicalScore: number; // 0 - 100
  currentRisk: RiskLevel;
  currentScore: number; // 0 - 100
  populationExposed: {
    total: number;
    red: number;
    orange: number;
    yellow: number;
    area_sqkm?: number;
  };
  currentConditions: {
    rainfall24h_mm: number;
    rainfall3d_mm: number;
    rainfall7d_mm: number;
    rainfallAnomaly_percent?: number;
    soilMoisture_percent?: number;
    temperature_c?: number;
    windSpeed_kmh?: number;
    elevation_m?: number;
    slope_deg?: number;
  };
  historicalEvidence: {
    totalEventsRecorded: number;
    eventsLast5Years: number;
    latestEventDate: string;
    latestEventDescription: string;
    recurrenceTendency: string;
  };
  aiExplanation: string;
  recommendedAction: string;
  provenance: Provenance;
  lastUpdated: string;
}

export interface AlertItem {
  id: string;
  hazard: HazardType;
  severity: RiskLevel;
  location: string;
  state: string;
  district: string;
  latitude: number;
  longitude: number;
  riskScore: number;
  currentCondition: string;
  historicalEvidence: string;
  forecastEvidence: string;
  reason: string;
  recommendedAction: string;
  populationAtRisk: number;
  timestamp: string;
  dataSources: Provenance[];
  isActive: boolean;
}

export interface HistoricalEvent {
  id: string;
  hazard: HazardType;
  title: string;
  location: string;
  state: string;
  district: string;
  latitude: number;
  longitude: number;
  date: string;
  year: number;
  month: number;
  severity: RiskLevel;
  fatalities?: number;
  displaced?: number;
  economicImpact_inr_cr?: number;
  description: string;
  source: string;
  sourceUrl: string;
  rainfallRecord_mm?: number;
  rainfall_mm?: number;
  magnitude?: number; // for earthquakes
  cycloneCategory?: string; // for cyclones
  economicLoss_cr?: number;
  coordinates?: [number, number];
}

export interface RelocationSite {
  id: string;
  name: string;
  type: 'cyclone_shelter' | 'flood_relief_camp' | 'multi_purpose_evacuation_center' | 'school_community_shelter';
  state: string;
  district: string;
  address: string;
  latitude: number;
  longitude: number;
  capacity: number;
  currentOccupancy: number;
  status: 'operational' | 'standby' | 'active_evacuation' | 'full' | 'READY' | 'STANDBY' | 'FULL';
  contactPerson: string;
  contactPhone: string;
  amenities: string[];
  distanceKm?: number; // Calculated relative to search point
  verifiedBy: string;
  lastInspected: string;
  lastInspectionDate?: string;
}

export interface CitizenReport {
  id: string;
  hazardType: HazardType;
  locationName: string;
  latitude: number;
  longitude: number;
  coordinates?: [number, number];
  district: string;
  state: string;
  description: string;
  severity: RiskLevel;
  reportedAt: string;
  reporterName: string;
  reporterContact?: string;
  reporterPhone?: string;
  photoUrl?: string;
  status: 'PENDING_VERIFICATION' | 'APPROVED' | 'VERIFIED' | 'REJECTED';
  adminNotes?: string;
  verifiedAt?: string;
}

export type CitizenHazardReport = CitizenReport;

export interface MLModelMetrics {
  modelName: string;
  architecture: string;
  precision: number;
  recall: number;
  f1Score: number;
  rocAuc: number;
  testSamples: number;
  trainingDataset: string;
  validationSplit: string;
  status: 'operational' | 'validated' | 'experimental_research';
  confusionMatrix: {
    truePositive: number;
    falsePositive: number;
    trueNegative: number;
    falseNegative: number;
  };
}

export interface AIRiskAnalysisResult {
  location: {
    name: string;
    latitude: number;
    longitude: number;
    state: string;
    district: string;
    isInsideIndia: boolean;
  };
  hazardType: HazardType;
  aiRiskLevel: RiskLevel;
  riskScore: number; // 0 - 100
  historicalSusceptibility: RiskLevel;
  historicalScore: number;
  modelInference: {
    cnnSpatialScore: number;
    lstmSequenceScore: number;
    resnetFeatureStatus: string;
    ensembleConfidence: number; // actual calculated ensemble agreement
    modelWeights: {
      cnnSpatial: number;
      lstmTemporal: number;
      geospatialPhysics: number;
      historicalPrior: number;
    };
  };
  currentConditions: {
    rainfall24h_mm: number;
    rainfall3d_mm: number;
    rainfall7d_mm: number;
    rainfallForecast24h_mm: number;
    soilMoisture_percent: number;
    temperature_c: number;
    windSpeed_kmh: number;
    elevation_m: number;
    slope_deg: number;
  };
  historicalEvidence: {
    nearbyHistoricalEventsCount: number;
    latestEventDate: string;
    latestEventTitle: string;
    recurrenceRatePerDecade: number;
    seasonalityPeakMonth: string;
  };
  populationExposed: {
    totalAtRisk: number;
    redZone: number;
    orangeZone: number;
    yellowZone: number;
    gridResolution: string;
    dataSource: string;
  };
  aiExplanation: string;
  recommendedAction: string;
  nearestShelters: RelocationSite[];
  provenance: Provenance[];
  timestamp: string;
}

export interface PopulationAtRiskSummary {
  nationalRedPopulation: number;
  nationalOrangePopulation: number;
  nationalYellowPopulation: number;
  totalPopulationAtRisk: number;
  totalAreaAffectedKm2: number;
  dataset: string;
  datasetYear: number;
  resolution: string;
  calculatedAt: string;
  stateBreakdown: {
    state: string;
    hazard: HazardType;
    riskLevel: RiskLevel;
    population: number;
    areaKm2: number;
  }[];
}
