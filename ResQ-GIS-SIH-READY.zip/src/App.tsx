import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { HomePage } from './components/HomePage';
import { DashboardPage } from './components/DashboardPage';
import { LiveAlertsPage } from './components/LiveAlertsPage';
import { MapView } from './components/MapView';
import { AIRiskAnalyzerPage } from './components/AIRiskAnalyzerPage';
import { HistoricalHazardsPage } from './components/HistoricalHazardsPage';
import { PopulationAtRiskPage } from './components/PopulationAtRiskPage';
import { RelocationSheltersPage } from './components/RelocationSheltersPage';
import { ReportHazardPage } from './components/ReportHazardPage';
import { AdminPanelPage } from './components/AdminPanelPage';
import { DownloadModal } from './components/DownloadModal';

import { RiskZone, AlertItem, HistoricalEvent, CitizenHazardReport } from './types';
import { VERIFIED_HISTORICAL_EVENTS } from './data/verifiedData';
import { Loader2 } from 'lucide-react';

export function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [riskZones, setRiskZones] = useState<RiskZone[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [historicalEvents, setHistoricalEvents] = useState<HistoricalEvent[]>(VERIFIED_HISTORICAL_EVENTS);
  const [pendingReportsCount, setPendingReportsCount] = useState<number>(1);
  const [selectedZoneForAI, setSelectedZoneForAI] = useState<RiskZone | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Fetch initial GIS layers and alerts from the Express server
  const loadData = async () => {
    try {
      const [zonesRes, alertsRes, reportsRes] = await Promise.all([
        fetch('/api/map/risk-zones'),
        fetch('/api/alerts'),
        fetch('/api/admin/reports')
      ]);

      if (zonesRes.ok) {
        const zData = await zonesRes.json();
        setRiskZones(zData.zones || []);
      }
      if (alertsRes.ok) {
        const aData = await alertsRes.json();
        setAlerts(aData.alerts || []);
      }
      if (reportsRes.ok) {
        const rData = await reportsRes.json();
        const pending = (rData.reports || []).filter((r: CitizenHazardReport) => r.status === 'PENDING_VERIFICATION');
        setPendingReportsCount(pending.length);
      }
    } catch (err) {
      console.error('Initial data fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSelectZoneForAI = (zone: RiskZone) => {
    setSelectedZoneForAI(zone);
    setCurrentPage('ai-analyzer');
  };

  const redAlertCount = alerts.filter(a => a.severity === 'RED').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Navbar */}
      <Navbar
        activeAlerts={alerts}
        onNavigate={setCurrentPage}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
      />

      {/* Main Content Layout with Sidebar */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        <Sidebar
          currentPage={currentPage}
          onNavigate={setCurrentPage}
          redAlertCount={redAlertCount}
          pendingReportsCount={pendingReportsCount}
        />

        {/* Dynamic Page View Container */}
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {isLoading ? (
            <div className="h-full flex flex-col items-center justify-center p-12 text-slate-400 space-y-3">
              <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
              <p className="text-xs font-mono">Initializing India Sovereign GIS & Sensor Streams...</p>
            </div>
          ) : (
            <>
              {currentPage === 'home' && (
                <HomePage
                  riskZones={riskZones}
                  activeAlerts={alerts}
                  onNavigate={setCurrentPage}
                  onOpenDownload={() => setIsDownloadModalOpen(true)}
                />
              )}

              {currentPage === 'dashboard' && (
                <DashboardPage
                  riskZones={riskZones}
                  activeAlerts={alerts}
                  historicalEvents={historicalEvents}
                  onNavigate={setCurrentPage}
                  onSelectZoneForAI={handleSelectZoneForAI}
                />
              )}

              {currentPage === 'map' && (
                <MapView
                  riskZones={riskZones}
                  onSelectLocationForAI={handleSelectZoneForAI}
                />
              )}

              {currentPage === 'alerts' && (
                <LiveAlertsPage
                  alerts={alerts}
                  onNavigateToMap={() => setCurrentPage('map')}
                />
              )}

              {currentPage === 'ai-analyzer' && (
                <AIRiskAnalyzerPage
                  initialZone={selectedZoneForAI}
                  onNavigateToShelters={() => setCurrentPage('relocation')}
                />
              )}

              {currentPage === 'historical' && (
                <HistoricalHazardsPage
                  historicalEvents={historicalEvents}
                  onNavigateToMap={() => setCurrentPage('map')}
                />
              )}

              {currentPage === 'population' && (
                <PopulationAtRiskPage riskZones={riskZones} />
              )}

              {currentPage === 'relocation' && (
                <RelocationSheltersPage riskZones={riskZones} />
              )}

              {currentPage === 'report' && (
                <ReportHazardPage
                  onSubmitSuccess={() => {
                    loadData();
                  }}
                />
              )}

              {currentPage === 'admin' && (
                <AdminPanelPage />
              )}
            </>
          )}
        </main>
      </div>

      {/* SIH Download Package Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}

export default App;
